﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02ProvinceCitySelect
{
    public class AreaInfo
    {

        public string AreaName { get; set; }

        public int AreaPId { get; set; }

        public int AreaId { get; set; }

        public override string ToString()
        {
            return AreaName;
        }
    }
}
