namespace Spring.AopQuickStart
{
	public interface IIsModified
	{
        bool IsModified { get; set; }
	}
}
