namespace Spring.MsmqQuickStart.Server.Gateways
{
    public interface IMarketDataService
    {
        void SendMarketData();
    }
}