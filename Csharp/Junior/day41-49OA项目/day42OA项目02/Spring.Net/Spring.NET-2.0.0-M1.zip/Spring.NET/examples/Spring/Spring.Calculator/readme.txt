In order to be able to run the Calculator example with VS2003 you will need 
to create 'Spring.Calculator.2003' virtual directory using IIS Administrator and point it to :
 "examples\Spring\Spring.Calculator\Spring.Calculator.Web.2003"


Documentation related to this example :
http://www.springframework.net/doc-latest/reference/html/remoting-quickstart.html






